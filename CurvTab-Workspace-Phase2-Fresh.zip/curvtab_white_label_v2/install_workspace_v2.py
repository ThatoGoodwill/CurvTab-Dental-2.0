#!/usr/bin/env python3
"""CurvTab white-label v2 targeted installer: no automatic migrations or server restarts."""
from pathlib import Path
from datetime import datetime, timezone
import shutil, sys

root=Path.cwd()
app=root/'frontend/src/App.tsx'
entity=root/'backend/CurvTabDental.Domain/Entities/PracticeAppearance.cs'
controller=root/'backend/CurvTabDental.API/Controllers/PracticeAppearanceController.cs'
hook=root/'frontend/src/hooks/usePracticeAppearance.ts'
page=root/'frontend/src/pages/AppearanceSettingsPage.tsx'
old_css=root/'frontend/src/PracticeAppearanceTheme.css'
page_css=root/'frontend/src/pages/AppearanceSettingsPage.css'
new_css=root/'frontend/src/PracticeWorkspaceV2.css'
paths=[app,entity,controller,hook,page,old_css,page_css]
for p in paths:
    if not p.is_file():sys.exit(f'STOP: Phase 1 file missing: {p}. No changes made.')
if new_css.exists() or 'ct-nav-top' in app.read_text():sys.exit('STOP: v2 appears already installed. No changes made.')
texts={p:p.read_text() for p in paths}
def replace(p,old,new,count=1):
    txt=texts[p]
    occurrences=txt.count(old)
    if occurrences!=count:sys.exit(f'STOP: expected {count} anchor(s) in {p.name}, found {occurrences}: {old[:70]!r}. No changes made.')
    texts[p]=txt.replace(old,new,count)

# Persistence: two new additive columns in the existing per-practice row.
replace(entity,'    public string LayoutPreset { get; set; } = "Classic";', '''    public string LayoutPreset { get; set; } = "Classic";
    public string NavigationMode { get; set; } = "Sidebar";
    public string EnabledModulesJson { get; set; } = "[\\"Patients\\",\\"Appointments\\",\\"Daily Patients\\",\\"Consultations\\",\\"Checkout & Payments\\",\\"Dental Charting\\",\\"Orthodontics\\"]";''')
# The next migration will map these scalar strings to varchar/text columns.
ctx=root/'backend/CurvTabDental.Infrastructure/Persistence/DentalDbContext.cs'
if not ctx.is_file():sys.exit('STOP: database context missing. No changes made.')
texts[ctx]=ctx.read_text()
replace(ctx, '            entity.Property(x => x.LayoutPreset).IsRequired().HasMaxLength(20);', '''            entity.Property(x => x.LayoutPreset).IsRequired().HasMaxLength(20);
            entity.Property(x => x.NavigationMode).IsRequired().HasMaxLength(12);
            entity.Property(x => x.EnabledModulesJson).IsRequired().HasColumnType("text");''')

replace(controller,'using System.Text.RegularExpressions;', 'using System.Text.RegularExpressions;\nusing System.Text.Json;')
replace(controller,'''        string AccentColor,
        string LayoutPreset);''','''        string AccentColor,
        string LayoutPreset,
        string NavigationMode,
        string[] EnabledModules);''')
replace(controller,'public sealed class PracticeAppearanceController : ControllerBase\n{','''public sealed class PracticeAppearanceController : ControllerBase
{
    private static readonly string[] DefaultModules = [
        "Patients", "Appointments", "Daily Patients", "Consultations",
        "Checkout & Payments", "Dental Charting", "Orthodontics"
    ];
    private static readonly HashSet<string> AllowedModules = new(DefaultModules, StringComparer.Ordinal);
''')
replace(controller,'return Ok(new AppearanceUpdate(practice.Name, "", "#126CE5", "#14B8A6", "Classic"));', 'return Ok(new AppearanceUpdate(practice.Name, "", "#126CE5", "#14B8A6", "Classic", "Sidebar", DefaultModules));')
replace(controller,'''        if (preset is not ("Classic" or "Compact" or "Clinical"))
            return BadRequest(new { message = "Choose a supported layout preset." });''','''        if (preset is not ("Classic" or "Compact" or "Clinical"))
            return BadRequest(new { message = "Choose a supported layout preset." });
        if (request.NavigationMode is not ("Sidebar" or "Topbar"))
            return BadRequest(new { message = "Choose Sidebar or Topbar navigation." });
        if (request.EnabledModules is null || request.EnabledModules.Any(m => !AllowedModules.Contains(m)))
            return BadRequest(new { message = "Invalid module selection." });
        if (request.EnabledModules.Distinct(StringComparer.Ordinal).Count() != request.EnabledModules.Length)
            return BadRequest(new { message = "Duplicate modules are not allowed." });''')
replace(controller,'        row.LayoutPreset = preset;','''        row.LayoutPreset = preset;
        row.NavigationMode = request.NavigationMode;
        row.EnabledModulesJson = JsonSerializer.Serialize(request.EnabledModules);''')
replace(controller,'''    private static AppearanceUpdate ToDto(PracticeAppearance row) => new(
        row.DisplayName, row.Tagline, row.PrimaryColor, row.AccentColor, row.LayoutPreset);''','''    private static AppearanceUpdate ToDto(PracticeAppearance row) => new(
        row.DisplayName, row.Tagline, row.PrimaryColor, row.AccentColor, row.LayoutPreset,
        row.NavigationMode is "Topbar" ? "Topbar" : "Sidebar", ReadModules(row.EnabledModulesJson));

    private static string[] ReadModules(string? json)
    {
        try
        {
            var modules = JsonSerializer.Deserialize<string[]>(json ?? "") ?? DefaultModules;
            return modules.Where(m => AllowedModules.Contains(m)).Distinct(StringComparer.Ordinal).ToArray();
        }
        catch (JsonException) { return DefaultModules; }
    }''')

replace(hook, "  layoutPreset: 'Classic' | 'Compact' | 'Clinical'", "  layoutPreset: 'Classic' | 'Compact' | 'Clinical'\n  navigationMode: 'Sidebar' | 'Topbar'\n  enabledModules: string[]")
replace(page, "import { Palette, Save, CheckCircle2, LayoutDashboard }", "import { Palette, Save, CheckCircle2, LayoutDashboard, PanelTop, PanelLeft, Blocks }")
replace(page,"  displayName: '', tagline: '', primaryColor: '#126CE5', accentColor: '#14B8A6', layoutPreset: 'Classic',", "  displayName: '', tagline: '', primaryColor: '#126CE5', accentColor: '#14B8A6', layoutPreset: 'Classic',\n  navigationMode: 'Sidebar', enabledModules: ['Patients','Appointments','Daily Patients','Consultations','Checkout & Payments','Dental Charting','Orthodontics'],")
replace(page,'type Props = { appearance: PracticeAppearance | null; onSaved: (value: PracticeAppearance) => void }', '''type Props = { appearance: PracticeAppearance | null; onSaved: (value: PracticeAppearance) => void }
const OPTIONAL_MODULES = ['Patients','Appointments','Daily Patients','Consultations','Checkout & Payments','Dental Charting','Orthodontics'] as const''')
replace(page,'''        <p className="appearance-note">This first release covers branding and layout presets. Secure image uploads and drag-and-drop modules are coming next.</p>''','''        <fieldset className="ct-v2-fieldset">
          <legend>Navigation position</legend>
          <div className="ct-v2-choice-row">
            <label className="ct-v2-choice"><input type="radio" name="navigationMode" checked={form.navigationMode === 'Sidebar'}
              onChange={() => update({navigationMode:'Sidebar'})}/><PanelLeft size={18}/> Left sidebar</label>
            <label className="ct-v2-choice"><input type="radio" name="navigationMode" checked={form.navigationMode === 'Topbar'}
              onChange={() => update({navigationMode:'Topbar'})}/><PanelTop size={18}/> Upper navigation</label>
          </div>
        </fieldset>
        <fieldset className="ct-v2-fieldset">
          <legend><Blocks size={17}/> Workspace modules</legend>
          <p className="appearance-note">Choose which modules appear for your staff. Individual staff permissions still apply. Dashboard, Settings and Profile are always available.</p>
          <div className="ct-v2-module-grid">
            {OPTIONAL_MODULES.map(module => <label className="ct-v2-module" key={module}>
              <input type="checkbox" checked={form.enabledModules.includes(module)} onChange={event => update({
                enabledModules: event.target.checked
                  ? [...form.enabledModules, module]
                  : form.enabledModules.filter(item => item !== module)
              })}/> <span>{module}</span>
            </label>)}
          </div>
        </fieldset>
        <p className="appearance-note">Logo and slideshow uploads are a separate upcoming phase.</p>''')
replace(page,'''        <div className="appearance-preview-cards"><div>Patients</div><div>Appointments</div><div>Consultations</div></div>
        <p>Layout: {form.layoutPreset}</p>''','''        <div className="ct-v2-preview-nav">
          <strong>{form.navigationMode === 'Topbar' ? 'Upper navigation' : 'Sidebar navigation'}</strong>
          <span>Dashboard</span>
          {form.enabledModules.slice(0, 5).map(item => <span key={item}>{item}</span>)}
          <span>My Profile</span>
        </div>
        <div className="appearance-preview-cards">{form.enabledModules.slice(0,3).map(item => <div key={item}>{item}</div>)}</div>
        <p>Layout: {form.layoutPreset}</p>''')
replace(page,'Your staff will receive the saved colours and display name after they open or refresh their workspace.', 'Saved branding, menu position and module visibility will be applied to your staff workspace after refresh.')

# App: existing v1 already loads appearance; now drive nav mode and hide selected modules in the UI only.
replace(app,"import './PracticeAppearanceTheme.css'", "import './PracticeAppearanceTheme.css'")  # validate
if "import './ClientUXRepairs.css'" not in texts[app]:sys.exit('STOP: expected ClientUXRepairs CSS import missing. No changes made.')
replace(app,"import './ClientUXRepairs.css'", "import './ClientUXRepairs.css'\nimport './PracticeWorkspaceV2.css'")
replace(app,'''  const practiceThemeStyle = appearance ? ({''','''  const isModuleVisible = (name: string) => !appearance || ![
    'Patients','Appointments','Daily Patients','Consultations',
    'Checkout & Payments','Dental Charting','Orthodontics'
  ].includes(name) || appearance.enabledModules.includes(name)
  const practiceThemeStyle = appearance ? ({''')
replace(app,'<div className={`app-shell ${appearance ? `ct-layout-${appearance.layoutPreset.toLowerCase()}` : \'\'}`}', '''<div className={`app-shell ${appearance ? `ct-layout-${appearance.layoutPreset.toLowerCase()} ${appearance.navigationMode === 'Topbar' ? 'ct-nav-top' : 'ct-nav-sidebar'}` : ''}`}''')
replace(app,'{navigation.map((item) => {','{navigation.filter(item => isModuleVisible(item.name)).map((item) => {')
for role, label in [('Dentist','Daily Patients'),('Dentist','Consultations'),('Receptionist','Checkout & Payments'),('Dentist','Dental Charting'),('Dentist','Orthodontics')]:
    pass
# Conditional sections: wrap individual nav item, rather than hide page routes.
replace(app,"{role === 'Dentist' && (\n            <button\n              type=\"button\"\n              className={section === 'Daily Patients'", "{role === 'Dentist' && isModuleVisible('Daily Patients') && (\n            <button\n              type=\"button\"\n              className={section === 'Daily Patients'")
# The Consultations + legacy Medical Records group: keep medical record navigation hidden unless Consultations selected.
replace(app,"{role === 'Dentist' && (\n            <>\n              <button type=\"button\"\n                className={section === 'Consultations'", "{role === 'Dentist' && isModuleVisible('Consultations') && (\n            <>\n              <button type=\"button\"\n                className={section === 'Consultations'")
replace(app,"{(role === 'Receptionist' || role === 'PracticeAdmin') && (", "{(role === 'Receptionist' || role === 'PracticeAdmin') && isModuleVisible('Checkout & Payments') && (")
# Dentist specialties are wrapped in a shared fragment, so condition on each button individually.
replace(app,"{role === 'Dentist' && (\n            <>\n              <button type=\"button\"\n                className={section === 'Dental Charting'", "{role === 'Dentist' && (\n            <>\n              {isModuleVisible('Dental Charting') && <button type=\"button\"\n                className={section === 'Dental Charting'")
replace(app,'<Activity size={19} /><span>Dental Charting</span>\n              </button>', '<Activity size={19} /><span>Dental Charting</span>\n              </button>}')
replace(app,'              <button type="button"\n                className={section === \'Orthodontics\'', '              {isModuleVisible(\'Orthodontics\') && <button type="button"\n                className={section === \'Orthodontics\'')
replace(app,'<Stethoscope size={19} /><span>Orthodontics</span>\n              </button>', '<Stethoscope size={19} /><span>Orthodontics</span>\n              </button>}')

# Replace V1 theme with V2 override sourced from package for a single predictable new CSS file.
new_css_content=(Path(__file__).resolve().parent/'PracticeWorkspaceV2.css').read_text()
backup=root/'.curvtab-workspace-backups'/datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
for file in texts:
    dst=backup/file.relative_to(root);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dst)
for file,content in texts.items():file.write_text(content)
new_css.write_text(new_css_content)
print('SUCCESS: Appearance, module visibility, and sidebar/topbar preferences installed.')
print('Backups:',backup)
print('NEXT: build backend + frontend, inspect EF migration before updating PostgreSQL.')
