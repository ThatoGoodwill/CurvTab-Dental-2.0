# CurvTab Dental — White Label Phase 2

Adds tenant-specific UI module visibility, sidebar/topbar navigation, and forces saved brand colours to win over the existing client-recovery CSS. This **extends white-label phase 1**, not a standalone installation.

## Scope and safety

- PracticeAdmin edits, other staff read, via the existing practice appearance API.
- No clinical data is deleted. No modules are uninstalled. Module choices hide the *navigation links*, not API or page access. Backend role checks still govern access.
- The top navigation is horizontal on desktops >=900px, with the existing mobile sidebar retained on smaller screens.
- No logos, custom slideshow uploads or drag/drop builder in this phase.
- No automatically performed database update. Installer checks anchors and exits before edits if code differs. Backups stored in `.curvtab-workspace-backups/`.
- Default enabled modules: Patients, Appointments, Daily Patients, Consultations, Checkout & Payments, Dental Charting, Orthodontics. Dashboard, Practice Settings, Appearance & Workspace and My Profile cannot be hidden.

## Install in Codespaces

Upload ZIP to the repository root, then:

```bash
cd /workspaces/CurvTab-Dental-2.0
unzip curvtab_white_label_v2.zip -d /tmp/curvtab-white-label-v2
python3 /tmp/curvtab-white-label-v2/curvtab_white_label_v2/install_workspace_v2.py

dotnet build backend/CurvTabDental.API/CurvTabDental.API.csproj
cd frontend && npm run build && npm run lint && cd ..
```

STOP if the installer or either build fails. Share output to diagnose; do not run migrations until resolved.

## Backup database and apply additive migration

```bash
cd /workspaces/CurvTab-Dental-2.0
docker compose up -d db
docker exec curvtab-db sh -lc 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$HOME/curvtab-pre-workspace-v2.dump"
test -s "$HOME/curvtab-pre-workspace-v2.dump" || exit 1

DB_USER="$(docker exec curvtab-db printenv POSTGRES_USER)"
DB_NAME="$(docker exec curvtab-db printenv POSTGRES_DB)"
DB_PASS="$(docker exec curvtab-db printenv POSTGRES_PASSWORD)"
export ConnectionStrings__DentalDatabase="Host=localhost;Port=5432;Database=$DB_NAME;Username=$DB_USER;Password=$DB_PASS"

dotnet ef migrations add AddPracticeWorkspaceCustomization \
  --project backend/CurvTabDental.Infrastructure \
  --startup-project backend/CurvTabDental.API \
  --context DentalDbContext
```

**Review the generated migration file** in `backend/CurvTabDental.Infrastructure/Migrations/`. It must add only columns `NavigationMode` and `EnabledModulesJson` to `PracticeAppearances` and must NOT drop tables/columns. If anything else appears, stop. After review:

```bash
dotnet ef database update \
  --project backend/CurvTabDental.Infrastructure \
  --startup-project backend/CurvTabDental.API \
  --context DentalDbContext
unset DB_USER DB_NAME DB_PASS ConnectionStrings__DentalDatabase

docker compose build api
docker compose up -d --no-deps api
curl -i http://localhost:8080/api/health
```

**Never use `docker compose down -v`.** Your existing patient data must be retained.

## Test

Sign in as the existing PracticeAdmin. In **Appearance & Workspace** select contrasting primary/accent colours, choose **Upper navigation**, turn off **Orthodontics**, click Save Appearance and refresh. The navigation should appear horizontally on a desktop and Orthodontics should no longer appear in the Dentist's navigation after sign-in. The clinician's clinical authorization is unchanged. Switch back to Left sidebar and save to restore. Verify another practice still retains its own appearance.

## Caveats

- Existing Dashboard slideshow is not replaced with custom uploaded images in phase 2.
- A hidden module is not an entitlement boundary. To restrict features by subscription, enforce it server-side, separately from this presentation preference.
- The client-recovery CSS may differ in your Codespace: verify manually on desktop/mobile; restore from backup if something visually conflicts.
