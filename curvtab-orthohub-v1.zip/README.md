# CurvTab Dental 2.0 — OrthoHub V1

## What this delivers

- **Overview**: upcoming case review dates (next 14 days), overdue review dates, unscheduled reviews, planning queue, and real clinical progress notes across the current practice.
- **Cases**: searchable, filterable, responsive practice-wide orthodontic case cards; Open Case and Financials route into the existing clinical/financial workspace.
- **Patients, Reports, Analysis**: existing pages are preserved for subsequent upgrades.
- **Data**: dentist-only `GET /api/dentist/orthodontics/overview`, practice-scoped joins to existing `Patients`, `OrthodonticCases`, and `OrthodonticProgressNotes`; no new tables or database migrations.

## How to install in Codespaces

Upload this ZIP to `/workspaces/CurvTab-Dental-2.0`, then:

```bash
cd /workspaces/CurvTab-Dental-2.0
unzip -o curvtab-orthohub-v1.zip -d /tmp/curvtab-orthohub-v1
python3 /tmp/curvtab-orthohub-v1/install_orthohub.py
cd frontend && npm run build
```

Build the backend after frontend succeeds:

```bash
cd /workspaces/CurvTab-Dental-2.0
DOCKER_BUILDKIT=0 docker build -t curvtab-api-repaired:latest -f Dockerfile .
docker compose up -d --no-build --no-deps --force-recreate api
```

Make sure the database is running and healthy before recreating the API. Restart Vite if needed; check port 5173 or the port printed by Vite.

## Requirements and limits

- API is **Dentist-only**, the same role as the existing orthodontic clinical controller. Staff who lack Dentist role cannot open the overview.
- The API returns **up to 250** current practice cases and 12 recent visit notes; a warning appears if cases are truncated. Pagination is a planned next phase.
- Dashboard reviews come from `NextReviewDate` on the case, **not** from the appointments scheduling table. A recorded date does not prove the appointment was booked. Dates are compared to the browser's local calendar date.
- We intentionally do **not** show outstanding balances or paid percentage in the case list yet. Financial agreements and planned instalments are not evidence of real received payments.
- Current Reports and Analysis are **not yet** the complete practice-wide reports seen in the inspiration screenshots. They remain exactly as implemented in the existing project.
- The New Case flow continues to use your existing clinical form and API.
- This package has not been built or executed against your private Codespace repository. It uses only code details you shared. Both the TypeScript and .NET builds are required before deployment.

## Safety

- Before installing, keep a secure off-Codespace copy of database and uploaded media backups.
- This installer never runs database migrations or modifies patient records. It backs up `OrthodonticsPage.tsx` under `.curvtab-ortho-layout-backups/` before modifying it.
- Do not commit patient data, clinical images, backups or passwords to GitHub.
- Do not use `docker compose down -v` or prune database volumes.
- The dashboard uses patient names, clinical notes and dates; only expose it to authenticated, authorised clinical staff over private connections.
