#!/usr/bin/env python3
"""Apply CurvTab OrthoHub V1 to the existing Codespaces source, without DB migrations.
Usage: python3 install_orthohub.py    (run from repo root)
"""
from pathlib import Path
from datetime import datetime
import shutil
import re
import sys

root = Path.cwd()
bundle = Path(__file__).resolve().parent
page = root / 'frontend/src/pages/OrthodonticsPage.tsx'
nav_file = page
frontend_src = root / 'frontend/src/pages'
api_dest = root / 'backend/CurvTabDental.API/Controllers/OrthodonticsOverviewController.cs'
new_files = [
    (bundle/'frontend/src/pages/OrthoHub.tsx', frontend_src/'OrthoHub.tsx'),
    (bundle/'frontend/src/pages/OrthoHub.css', frontend_src/'OrthoHub.css'),
    (bundle/'backend/CurvTabDental.API/Controllers/OrthodonticsOverviewController.cs', api_dest),
]
if not page.exists():
    sys.exit('Cannot find frontend/src/pages/OrthodonticsPage.tsx. Run from repository root.')
source = page.read_text()
if 'ORTHOHUB_V1' in source:
    sys.exit('OrthoHub V1 already integrated; no changes made.')
start = "      {activeTab === 'Dashboard' && ("
end = "      {activeTab === 'Reports' && ("
nav_old = "(['Dashboard', 'Patients', 'Reports', 'Analysis'] as const)"
nav_new = "(['Dashboard', 'Cases', 'Patients', 'Reports', 'Analysis'] as const)"
state_old = "'Dashboard' | 'Patients' | 'Reports' | 'Analysis'"
state_new = "'Dashboard' | 'Cases' | 'Patients' | 'Reports' | 'Analysis'"
checks = {
    'Dashboard block': source.count(start) == 1,
    'Reports block': source.count(end) == 1,
    'tab navigation': source.count(nav_old) == 1,
    'tab type union': source.count(state_old) == 1,
    'clinical patient state': 'selectPatient' in source and 'setWorkspaceTab' in source,
    'New Case state': 'setOpenNewCase' in source,
    'import location': "import OrthodonticCareTimeline from './OrthodonticCareTimeline'" in source,
    'expected app architecture': 'apiRequest' in source,
    'no file conflict': all(not dest.exists() for _, dest in new_files),
}
for name, passed in checks.items():
    if not passed: sys.exit(f'Preflight failed: {name}. Nothing changed. Share this error for an adjusted installer.')
start_idx = source.index(start)
end_idx = source.index(end, start_idx)
# We intentionally keep all other tabs, existing financial components and the clinical forms untouched.
replacement = '''      {/* ORTHOHUB_V1 — overview and practice-wide cases */}
      {activeTab === 'Dashboard' && (
        <OrthoHub mode="overview"
          onOpenCase={item => {
            selectPatient(item.patientId)
            setReload(v => v + 1)
            setCaseId(item.id)
            setDetails(null)
            setWorkspaceTab('Clinical')
            setActiveTab('Patients')
          }}
          onFinancials={item => {
            selectPatient(item.patientId)
            setReload(v => v + 1)
            setCaseId(item.id)
            setActiveTab('Reports')
          }}
          onNewCase={() => {
            setActiveTab('Patients')
            setWorkspaceTab('Clinical')
            setOpenNewCase(true)
          }}
          onCases={() => setActiveTab('Cases')}
          onReports={() => setActiveTab('Reports')}
        />
      )}

      {activeTab === 'Cases' && (
        <OrthoHub mode="cases"
          onOpenCase={item => {
            selectPatient(item.patientId)
            setReload(v => v + 1)
            setCaseId(item.id)
            setDetails(null)
            setWorkspaceTab('Clinical')
            setActiveTab('Patients')
          }}
          onFinancials={item => {
            selectPatient(item.patientId)
            setReload(v => v + 1)
            setCaseId(item.id)
            setActiveTab('Reports')
          }}
          onNewCase={() => {
            setActiveTab('Patients')
            setWorkspaceTab('Clinical')
            setOpenNewCase(true)
          }}
          onCases={() => setActiveTab('Cases')}
          onReports={() => setActiveTab('Reports')}
        />
      )}

'''
updated = source[:start_idx] + replacement + source[end_idx:]
# Remove dashboard-only state from an earlier experimental practice-wide
# implementation. It becomes unused after the dashboard JSX is replaced.
legacy_start = '  // CT_ORTHO_PRACTICE_DASHBOARD'
legacy_end = '  // CT_ORTHO_PHASE4'
if legacy_start in updated:
    if updated.count(legacy_start) != 1 or updated.count(legacy_end) != 1:
        sys.exit('Unexpected earlier dashboard state; no files changed.')
    i = updated.index(legacy_start)
    j = updated.index(legacy_end, i)
    updated = updated[:i] + updated[j:]
updated = updated.replace(nav_old, nav_new, 1).replace(state_old, state_new, 1)
updated = updated.replace(
    "import OrthodonticCareTimeline from './OrthodonticCareTimeline'",
    "import OrthodonticCareTimeline from './OrthodonticCareTimeline'\nimport OrthoHub from './OrthoHub'",
    1,
)
# Rename only the visible nav label. State value remains Dashboard so other code still works.
updated = updated.replace('\n            {tab}\n', "\n            {tab === 'Dashboard' ? 'Overview' : tab}\n", 1)
# Avoid duplicate New Case buttons: hub has its own action in Overview and Cases.
old_button = '      <div className="ct-ortho-primary-actions">'
if old_button in updated:
    a = updated.index(old_button)
    b = updated.find('      </div>', a)
    if b != -1:
        b += len('      </div>')
        updated = (updated[:a] +
                   "      {(activeTab !== 'Dashboard' && activeTab !== 'Cases') && (\n" +
                   updated[a:b] +
                   "\n      )}" + updated[b:])
backup = root/'.curvtab-ortho-layout-backups'/('orthohub-v1-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
backup.mkdir(parents=True, exist_ok=True)
shutil.copy2(page, backup/page.name)
try:
    for original, destination in new_files:
        shutil.copy2(original, destination)
    page.write_text(updated)
except Exception:
    page.write_text(source)
    for _, destination in new_files:
        destination.unlink(missing_ok=True)
    raise
print('OrthoHub V1 installed. Existing Patients, Reports, Analysis and clinical forms retained.')
print('Backup:', backup)
print('Next: cd frontend && npm run build')
print('Then: cd .. && DOCKER_BUILDKIT=0 docker build -t curvtab-api-repaired:latest -f Dockerfile .')
