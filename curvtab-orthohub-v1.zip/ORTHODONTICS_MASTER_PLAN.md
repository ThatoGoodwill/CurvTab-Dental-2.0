# CurvTab Dental 2.0 — Orthodontics module architecture

## Principle
One canonical practice-scoped Patient entity, several distinct specialist records.
`OrthodonticCase.PatientId` references the registered patient. The orthodontic workflow may have its own screens and permissions but never duplicates patient identities.

## Information architecture

1. **Overview:** Practice-wide attention queue, review dates, documented recent visits, shortcuts to patients/cases. NO large KPI counters or treatment completion doughnut. Planned appointment integration must use real booking records rather than case-level review dates.
2. **Cases:** Practice-wide searchable cards, status filters, assigned clinician and case-level information, verified financial status where supported. Open Case, Edit, Archive actions subject to permission and audit. Existing status transitions need expansion for Retention; never silently rewrite historical case states.
3. **Patients:** Orthodontic patient directory, primary patient identity from registration, specialist case record(s) for that patient, medical history summary and contraindications. Clinical record access restricted to authorised users.
4. **Assessment & Diagnosis:** Reason for attendance, clinical exam, occlusion findings, overjet/overbite/midlines/crowding/crossbite, specialist interpretation, photographs/radiographs, diagnoses. Templates must be clinician-entered, not auto-diagnose. Maintain versioned notes.
5. **Treatment Plan & Consent:** Alternatives, treatment goals, appliance, estimated timing, risks, consent record and clinician approval, versioned revisions. Don't treat planning as a payment event.
6. **Clinical Visits & Timeline:** Visit date, findings, adjustments, advice, next steps and next review, immutable author/time metadata, corrections through an auditable amendment procedure. Use existing `OrthodonticProgressNotes` where possible.
7. **Imaging & Documents:** Reuse existing `clinical-media` with patient/case scope, virus/type validation, access control, retention policy and auditable access; offer chronological comparison.
8. **Retention & Follow-up:** Distinct retention stage, retainer details, instructions, recurring reviews; closing a case is a clinical action, not a financial one.
9. **Reports:** Practice-wide case distribution, assessment-to-treatment conversion, review adherence, clinician activity, treatment types, financial agreements, actual cash receipts, ageing, instalment schedules, patient statements and exports. Distinguish booked revenue, receivables, and actual cash collected.
10. **Analysis:** Clinical trends and financial projections using transparent time windows; no fabricated progress percentages or misleading confidence.

## API and data phases

- Phase 1 (packaged): Dentist-only practice-wide overview and cases using existing tables. No schema migrations. Existing case write endpoints unchanged.
- Phase 2: Practice-wide clinical scheduling integration. Verify `Appointments` and dentist/orthodontic resource mapping; don't infer an appointment from `NextReviewDate`.
- Phase 3: Specialist assessment, plan, consent, retention and case assignments, after EF migration review and agreed clinical fields.
- Phase 4: Reconciled financial reporting. Trace agreements and actual payments via invoice/payment allocations; test refunds, write-offs, credits and partial payments.
- Phase 5: Secure edit/archive, comprehensive audit and permissions, exports and tests.

## Acceptance gates

- Practice isolation and explicit Dentist authorisation tests for every clinical endpoint.
- Patient A's orthodontic case does not appear under Patient B or a different practice.
- Creating a case updates existing patient record associations without duplicate patient creation.
- Case and visit states survive a restart and recovery from a backup.
- Financial amounts balance to invoices, payments, reversals and credits; no percentages from scheduled instalments.
- Deleted or corrected clinical data preserves appropriate audit and clinical retention requirements.
- All views work in light/dark mode and practice-selected accent colours; keyboard access, small screens and WCAG-oriented contrast checks.
- Backend and frontend builds pass and API contract tests succeed with authenticated test accounts.

## Known present limitations

The new overview exposes at most 250 cases and 12 recent notes. The existing finance panel is case-specific. Do not present these as fully practice-wide financial reporting until new, reconciled finance endpoints are built. No automated diagnosis, no unsafe direct deletion of patient records.
