using CurvTabDental.Domain.Common;

namespace CurvTabDental.Domain.Entities;

// A separate appearance configuration per tenant. Does not affect clinical data.
public sealed class PracticeAppearance : IPracticeOwned
{
    public Guid DentalPracticeId { get; set; }
    public string DisplayName { get; set; } = string.Empty;
    public string Tagline { get; set; } = string.Empty;
    public string PrimaryColor { get; set; } = "#126CE5";
    public string AccentColor { get; set; } = "#14B8A6";
    public string LayoutPreset { get; set; } = "Classic";
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}
