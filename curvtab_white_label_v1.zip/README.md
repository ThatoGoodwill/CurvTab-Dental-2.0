# CurvTab Dental — White-label Milestone 1

This phase provides **PracticeAdmin-only Appearance & Workspace** with practice display name, tagline, primary and accent colours, and **Classic / Compact / Clinical** layout presets. Settings are stored in a new `PracticeAppearances` table, tenant-filtered by `DentalPracticeId`. Dentist and Receptionist can read their practice's settings but not update them. SuperAdmin is not a practice tenant.

**Not yet included:** file uploads, practice-specific login URL, drag/drop module editor, per-role module ordering, subscription entitlement management. UI module visibility is not a replacement for backend authorization.

## Install

1. Upload/extract all package contents to your Codespace repository root, retaining the `backend/` and `frontend/` directories **inside this package** only as installation sources (do not overwrite existing repo directories). The simplest method is to upload the ZIP to root and run:

   ```bash
   unzip curvtab_white_label_v1.zip -d /tmp/curvtab-white-label
   python3 /tmp/curvtab-white-label/install_white_label_v1.py
   ```

   Run `python3` from `/workspaces/CurvTab-Dental-2.0`, not from `/tmp`. Installer checks expected anchor markers, creates backups, and changes the existing `App.tsx`/`DentalDbContext.cs` only after validating.

2. Build:

   ```bash
   dotnet build backend/CurvTabDental.API/CurvTabDental.API.csproj
   cd frontend && npm run build && npm run lint && cd ..
   ```

3. Check database health, **back up data**, create migration:

   ```bash
   docker compose up -d db
   docker exec curvtab-db pg_dump -U curvtab -d curvtabdb -Fc > "$HOME/curvtab-pre-appearance.dump"
   test -s "$HOME/curvtab-pre-appearance.dump" || exit 1
   DB_USER="$(docker exec curvtab-db printenv POSTGRES_USER)"
   DB_NAME="$(docker exec curvtab-db printenv POSTGRES_DB)"
   DB_PASS="$(docker exec curvtab-db printenv POSTGRES_PASSWORD)"
   export ConnectionStrings__DentalDatabase="Host=localhost;Port=5432;Database=$DB_NAME;Username=$DB_USER;Password=$DB_PASS"
   dotnet ef migrations add AddPracticeAppearance --project backend/CurvTabDental.Infrastructure --startup-project backend/CurvTabDental.API --context DentalDbContext
   ```

   **Inspect the migration.** Expected additive table `PracticeAppearances`, not dropped or altered clinical tables. If migration contains destructive operations, **STOP**. Only after inspection:

   ```bash
   dotnet ef database update --project backend/CurvTabDental.Infrastructure --startup-project backend/CurvTabDental.API --context DentalDbContext
   unset DB_PASS DB_USER DB_NAME ConnectionStrings__DentalDatabase
   docker compose build api
   docker compose up -d --no-deps api
   curl -i http://localhost:8080/api/health
   ```

4. Test as PracticeAdmin: **Appearance & Workspace** → edit branding → Save → refresh → check Dentist/Receptionist view in independent browser session. Then log in as a **second practice** and verify its branding stays different. Unauthorized `PUT /api/practice/appearance` as Dentist/Receptionist must return `403`.

5. Current login page is a shared platform login until we introduce practice-specific login links/domains. This is not yet a complete white-label deployment.

**Safe rollback:** Copies of prior `App.tsx` and `DentalDbContext.cs` are in `.curvtab-appearance-backups/<timestamp>/`. Do not delete clinical tables or roll back migrations against populated data without reviewing them.
