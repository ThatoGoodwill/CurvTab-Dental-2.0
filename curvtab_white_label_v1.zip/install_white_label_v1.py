#!/usr/bin/env python3
"""Install CurvTab white-label milestone 1 into an existing Codespace checkout.
Changes are audited and backed up. No migrations are run by this script.
"""
from pathlib import Path
from datetime import datetime
import shutil, sys

root = Path.cwd()
pkg = Path(__file__).resolve().parent
app = root/'frontend/src/App.tsx'
ctx = root/'backend/CurvTabDental.Infrastructure/Persistence/DentalDbContext.cs'
if not app.is_file() or not ctx.is_file():
    sys.exit('STOP: Run from repo root containing frontend/src/App.tsx and backend. No changes made.')
old = app.read_text()
db = ctx.read_text()
if 'usePracticeAppearance' in old or 'DbSet<PracticeAppearance>' in db:
    sys.exit('STOP: Appearance integration is already present. No changes made.')
checks = [
    "import { useAuth } from './auth/AuthContext'",
    "import './App.css'",
    "  | 'My Profile'",
    "  const { user, logout } = useAuth()",
    "    <div className=\"app-shell\">",
    "<strong>CurvTab Dental</strong>",
    "{ name: 'My Profile' as Section, icon: UserCircle },",
    "{section === 'My Profile' && (",
]
for q in checks:
    if q not in old:
        sys.exit('STOP: Current App.tsx differs at anchor '+repr(q)+'. No changes made; share App.tsx.')
for q in ('public DbSet<AuditEvent> AuditEvents => Set<AuditEvent>();', 'modelBuilder.Entity<AuditEvent>(entity =>'):
    if q not in db:sys.exit('STOP: DentalDbContext structure differs. No changes made.')

# Make all replacements in memory before touching disk.
new=old.replace("import { useAuth } from './auth/AuthContext'", "import { useAuth } from './auth/AuthContext'\nimport type { CSSProperties } from 'react'\nimport { usePracticeAppearance } from './hooks/usePracticeAppearance'\nimport AppearanceSettingsPage from './pages/AppearanceSettingsPage'",1)
new=new.replace("import './App.css'", "import './App.css'\nimport './PracticeAppearanceTheme.css'",1)
new=new.replace("  | 'My Profile'", "  | 'Appearance & Workspace'\n  | 'My Profile'",1)
new=new.replace("  const { user, logout } = useAuth()", "  const { user, logout } = useAuth()\n  const { appearance, setAppearance } = usePracticeAppearance(user?.practiceId)\n  const practiceThemeStyle = appearance ? ({\n    '--practice-primary': appearance.primaryColor,\n    '--practice-accent': appearance.accentColor,\n  } as CSSProperties) : undefined",1)
new=new.replace('    <div className="app-shell">', '''    <div className={`app-shell ${appearance ? `ct-layout-${appearance.layoutPreset.toLowerCase()}` : ''}`}
      data-practice-branded={appearance ? 'true' : undefined}
      style={practiceThemeStyle}>''',1)
new=new.replace('<strong>CurvTab Dental</strong>', "<strong>{appearance?.displayName || (user?.practiceName ?? 'CurvTab Dental')}</strong>",1)
# Scope to the second nav list, so SuperAdmin does not get appearance editor.
marker="{ name: 'My Profile' as Section, icon: UserCircle },"
pos=new.rfind(marker,0,new.index('  const dashboardTitles'))
if pos<0:sys.exit('STOP: Could not locate practice-specific sidebar. No changes made.')
new=new[:pos]+"...(canManageStaff ? [{ name: 'Appearance & Workspace' as Section, icon: Settings }] : []),\n        "+new[pos:]
render_anchor="          {/* PROFILE FOR ALL ROLES */}"
if render_anchor not in new:sys.exit('STOP: Profile component marker not found. No changes made.')
new=new.replace(render_anchor,"""          {/* PRACTICE ADMIN: WHITE-LABEL APPEARANCE */}
          {section === 'Appearance & Workspace' && isPracticeAdmin && appearance && (
            <AppearanceSettingsPage key={user?.practiceId ?? 'practice'}
              appearance={appearance} onSaved={setAppearance} />
          )}

"""+render_anchor,1)
# For views where roles are denied, also deny this section if not PracticeAdmin.
denied="(section === 'Dental Practices' && !isSuperAdmin)"
if denied in new:
    new=new.replace(denied, "(section === 'Appearance & Workspace' && !isPracticeAdmin) ||\n            "+denied,1)

newdb=db.replace('public DbSet<AuditEvent> AuditEvents => Set<AuditEvent>();',
    'public DbSet<AuditEvent> AuditEvents => Set<AuditEvent>();\n    public DbSet<PracticeAppearance> PracticeAppearances => Set<PracticeAppearance>();',1)
newdb=newdb.replace('modelBuilder.Entity<AuditEvent>(entity =>', '''modelBuilder.Entity<PracticeAppearance>(entity =>
        {
            entity.HasKey(x => x.DentalPracticeId);
            entity.HasQueryFilter(x => x.DentalPracticeId == CurrentPracticeId);
            entity.Property(x => x.DisplayName).IsRequired().HasMaxLength(100);
            entity.Property(x => x.Tagline).IsRequired().HasMaxLength(160);
            entity.Property(x => x.PrimaryColor).IsRequired().HasMaxLength(7);
            entity.Property(x => x.AccentColor).IsRequired().HasMaxLength(7);
            entity.Property(x => x.LayoutPreset).IsRequired().HasMaxLength(20);
            entity.HasOne<DentalPractice>().WithOne().HasForeignKey<PracticeAppearance>(x => x.DentalPracticeId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<AuditEvent>(entity =>''',1)

outputs={
    app:new,
    ctx:newdb,
}
for rel in [
    'backend/CurvTabDental.Domain/Entities/PracticeAppearance.cs',
    'backend/CurvTabDental.API/Controllers/PracticeAppearanceController.cs',
    'frontend/src/hooks/usePracticeAppearance.ts',
    'frontend/src/pages/AppearanceSettingsPage.tsx',
    'frontend/src/pages/AppearanceSettingsPage.css',
    'frontend/src/PracticeAppearanceTheme.css',
]:
    dest=root/rel
    if dest.exists():sys.exit('STOP: File already exists: '+rel+'. No changes made.')
    outputs[dest]=(pkg/rel).read_text()
backup=root/'.curvtab-appearance-backups'/datetime.now().strftime('%Y%m%d-%H%M%S')
backup.mkdir(parents=True,exist_ok=True)
for src in [app,ctx]:
    dst=backup/src.relative_to(root)
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
for dest,value in outputs.items():
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(value)
print('SUCCESS: Practice appearance API, UI, and per-practice theme installed.')
print('Backup:',backup)
print('NEXT: Build frontend/backend, back up PostgreSQL, generate and REVIEW EF migration before applying.')
