#!/usr/bin/env python3
"""Install the client-selected soft-white theme safely into CurvTab Dental 2.0.

Run from the repository root: python3 curvtab_client_soft_white.py
Upload the companion curvtab_client_soft_white.css into the SAME directory.
Only touches frontend/src/App.tsx and adds frontend/src/ClientSoftWhiteTheme.css.
"""
from pathlib import Path
from datetime import datetime, timezone
import shutil
import sys
import re

root = Path.cwd()
app = root / 'frontend/src/App.tsx'
css_in = root / 'curvtab_client_soft_white.css'
css_target = root / 'frontend/src/ClientSoftWhiteTheme.css'
import_stmt = "import './ClientSoftWhiteTheme.css'"

if not app.exists():
    sys.exit('ERROR: Run this file from the CurvTab-Dental-2.0 repository root.')
if not css_in.exists():
    sys.exit('ERROR: Upload curvtab_client_soft_white.css alongside this installer.')
source = app.read_text(encoding='utf-8')
if import_stmt in source or css_target.exists():
    sys.exit('Theme is already present, or theme CSS already exists. No changes made.')
if not ('<main' in source and ('app-shell' in source or 'className=' in source)):
    sys.exit('ERROR: Unknown App.tsx layout. No changes made.')
if css_in.stat().st_size < 1000:
    sys.exit('ERROR: CSS file seems incomplete. No changes made.')

backup = root / '.curvtab-ui-backups' / datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
backup.mkdir(parents=True)
shutil.copy2(app, backup / 'App.tsx')
try:
    # Put this stylesheet after other CSS imports, before the application code.
    # This is valid TSX and avoids import-order lint rules.
    css_imports = list(re.finditer(r"^import\s+['\"][^'\"]+\.css['\"]\s*;?\s*$", source, re.M))
    if css_imports:
        pos = css_imports[-1].end()
        modified = source[:pos] + '\n' + import_stmt + source[pos:]
    else:
        modified = import_stmt + '\n' + source
    app.write_text(modified, encoding='utf-8')
    shutil.copy2(css_in, css_target)
except Exception as exc:
    shutil.copy2(backup / 'App.tsx', app)
    css_target.unlink(missing_ok=True)
    sys.exit(f'ERROR: Changes rolled back: {exc}')

print('SUCCESS: Soft-white client theme installed.')
print('Backup:', backup)
print('Changes: App.tsx adds a CSS import; new ClientSoftWhiteTheme.css added.')
print('No backend, database, migration, role or API changes.')
print('NEXT: cd frontend && npm run build && npm run lint')
